function [L,U] = soal2(T)
  [n n] = size(T)
  L = eye(n)
  for i = 1:n-2
    L(i+1,i) = T(i+1,i)/T(i,i);
    T(i+1, [i i+1 i+2]) = T(i+1,[i i+1 i+2]) - L(i+1,i)*T(i,[i i+1 i+2]);
  endfor
  L(n, n-1) = T(n, n-1) / T(n-1, n-1);
  T(n, [n-1 n]) = T(n, [n-1 n]) - L(n, n-1) * T(n-1, [n-1 n]);
  U = triu(T)