function y = fungsi(x)
  # fungsi yang diberikan soal
  
  y = 1./(1+10*x.^2);